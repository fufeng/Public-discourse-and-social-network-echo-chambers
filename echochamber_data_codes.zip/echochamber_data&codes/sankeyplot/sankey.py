import pandas as pd
import chart_studio.plotly as py
from plotly.graph_objs import *
from collections import defaultdict

user = 'peterwu4084'
api = 'HkVqNYjnCLSXMAIrbkqS'
py.sign_in(user, api)

def map1(c):
    if c == 0:
        return 'Donald Trump'
    elif c == 1:
        return 'Hillary Clinton'
    elif c == 4:
        return 'Wavering Supporters'
    else:
        return 'others'
    
def map2(c):
    if c == 2:
        return 'Donald Trump'
    elif c == 1:
        return 'Hillary Clinton'
    elif c == 5:
        return 'Wavering Supporters'
    else:
        return 'others'

def map3(c):
    if c == 1:
        return 'Donald Trump'
    elif c == 0:
        return 'Hillary Clinton'
    elif c == 10:
        return 'Wavering Supporters'
    else:
        return 'others'

def color_map(c):
    if c == 'Donald Trump':
        return 'rgb(213,102,171)'
    elif c == 'Hillary Clinton':
        return 'rgb(45,114,183)'
    elif c == 'Wavering Supporters':
        return 'rgb(228,178,69)'
    else:
        return 'rgb(211,211,211)'
    
def color_map_alpha(c, alpha=0.6):
    if c == 'Donald Trump':
        return 'rgba(213,102,171,{:.1f})'.format(alpha)
    elif c == 'Hillary Clinton':
        return 'rgba(45,114,183,{:.1f})'.format(alpha)
    elif c == 'Wavering Supporters':
        return 'rgba(228,178,69,{:.1f})'.format(alpha)
    else:
        return 'rgba(211,211,211,{:.1f})'.format(alpha)

de1st = pd.read_csv('first_point.csv', index_col=0)
de2nd = pd.read_csv('second_point.csv', index_col=0)
de3rd = pd.read_csv('third_point.csv', index_col=0)

de1st.community = de1st.community.map(map1)
de2nd.community = de2nd.community.map(map2)
de3rd.community = de3rd.community.map(map3)

d12 = defaultdict(lambda : 0)
d23 = defaultdict(lambda : 0)

for Id in de1st.index:
    if Id in de2nd.index and de1st.loc[Id]['community'] != 'others' and de2nd.loc[Id]['community'] != 'others':
        d12[(de1st.loc[Id]['community'], de2nd.loc[Id]['community'])] += 1

for Id in de2nd.index:
    if Id in de3rd.index and de2nd.loc[Id]['community'] != 'others' and de3rd.loc[Id]['community'] != 'others':
        d23[(de2nd.loc[Id]['community'], de3rd.loc[Id]['community'])] += 1

links = [{'source': t[0]+'1', 'target': t[1]+'2', 'value': d12[t]} for t in d12]
links += [{'source': t[0]+'2', 'target': t[1]+'3', 'value': d23[t]} for t in d23]

communities = ['Donald Trump', 'Hillary Clinton', 'Wavering Supporters']
labels = ['Donald Trump: 5278', 'Donald Trump: 6554', 'Donald Trump: 6828', 'Hillary Clinton: 3807', 'Hillary Clinton: 3852', 'Hillary Clinton: 3507', 'Undecided: 298', 'Undecided: 228', 'Undecided: 31']
node_colors = ['rgb(213,102,171)','rgb(213,102,171)','rgb(213,102,171)','rgb(45,114,183)','rgb(45,114,183)','rgb(45,114,183)', 'rgb(228,178,69)','rgb(228,178,69)','rgb(228,178,69)']
node_x = [0, 0.5, 1] * 3
node_y = [0.1, 0, 0.3] + [0.5, 0.82, 0.84] + [0.4, 0.62, 0.64]

edge_colors = [color_map_alpha(t[0]) for t in d12] + [color_map_alpha(t[0]) for t in d23]
values = [d12[t] for t in d12] + [d23[t] for t in d23]
sources = [communities.index(t[0])*3 for t in d12] + [communities.index(t[0])*3+1 for t in d23]
targets = [communities.index(t[1])*3+1 for t in d12] + [communities.index(t[1])*3+2 for t in d23]

trace1 = {
  "link": {
    "color": edge_colors,
    "value": values,
    "source": sources, 
    "target": targets
  }, 
  "node": {
    "pad": 10, 
    "line": {
      "color": "black", 
      "width": 0
    }, 
    "color": node_colors,
    "label": labels,
    "thickness": 50,
    "x": node_x,
    "y": node_y
  }, 
  "textfont": {
      "size": 13,
      "family": "Helvetica"
  },
  "type": "sankey", 
  "domain": {
    "x": [0, 1], 
    "y": [0, 1]
  }, 
  "orientation": "h", 
  "valueformat": ".0f"
}
data = Data([trace1])
layout = {
  "font": {"size": 10}, 
  "title": "Individual-level opinion evolutions during the 2016 US presidential election.", 
  "height": 600,
  "width": 850
}
fig = Figure(data=data, layout=layout)

# plot_url = py.plot(fig) # 会打开浏览器

fig.write_image('fig1_new.pdf')