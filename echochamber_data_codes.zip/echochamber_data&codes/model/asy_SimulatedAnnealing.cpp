#include <fstream>
#include <cmath>
#include <iostream>
#include <string>
//#include <direct.h>
#include <algorithm>
#include <vector>
#include <ctime>
#include <cstdlib>
using namespace std;

#define N 10000
//#define T 1e50
#define Tmin 1e-50
#define r 0.99

vector<int>point[N];
double theta1,theta2,mu1,mu2,deta0,deta1,omega1,omega2,omega3,omega4,omega5;
int i0=3;
int state[N];//״̬��ֵ Ignorant-0,spreader1-1,spreader2-2 
struct Opinion{
	double current; double future; 
};
Opinion w[N];//���ֵ 
double R[8]={0.419,0.563,0.5017,0.4527,0.408,0.3673,0.4573,0.5228}; // real data
double S[8]={0.32,0.7,0.32,0.5,0.5,0.8,0.4,0.1}; //best fitting parameters
double Aver[8]={0,0,0,0,0,0,0,0}; //average of 100 simulations
double A[8]={0,0,0,0,0,0,0,0}; //each simulation result 
struct Spr{
	int ign;int s1;int s2;
}; //����I,S1��S2������ 
//Spr spr={0};


void impG(vector<int>point[],string filename);//����ͼ��
void Dynamics(vector<int>point[],int state[],double theta1, double theta2, double deta1,double mu1,double mu2,double omega,Opinion w[]);
void Simu(int s);
Spr summary(int state[]);

int main(){
	int i,j,k,l;
  double f,fnew;
	Spr spr;
	ofstream fout1;
	fout1.open("result_asy_SimulatedAnnealing.txt",ios::app);
    srand((unsigned)time(0));
    mu1=mu2=0.5;
		double B[8]={0,0,0,0,0,0,0,0};//sum of 100 simulations
    theta1=0.32,theta2=0.7,deta1=0.32,omega1=omega2=0.5,omega3=0.8,omega4=0.4,omega5=0.1;
    for(i=0;i<100;i++){
			Simu(1);
			for(j=0;j<8;j++){
      B[j]=B[j]+A[j];
			}
		} 
		f=0;
		for(i=0;i<8;i++){
      Aver[i]=B[i]/1000000;
			f=f+(Aver[i]-R[i])*(Aver[i]-R[i])*10000; 
		}
		f=f/8;
		//fout1<<Aver[0] << " " << Aver[1] << " " << Aver[2] <<" "  << Aver[3] << " " << Aver[4]<< " "<< Aver[5] << " " << Aver[6]<< " " << Aver[7] <<endl;
    fout1<<S[0] << " " << S[1] << " " << S[2] <<" "  << S[3] << " " << S[4]<< " "<< S[5] << " " << S[6]<< " " << S[7] << " " << f <<endl;
    
		k=0; 
		cout << k << endl; 
			double T=10;
	//	double Snew[8];
		while(T>Tmin && f>0.25){
     theta1 =(rand()%50)*0.01;
     theta2=0.5+(rand()%50+1)*0.01;
		 l=(theta2-theta1)/0.01;
     deta1=(rand()%l)*0.01;
		 omega1=(rand()%11)*0.1;
		 omega2=(rand()%11)*0.1;
		 omega3=0.6+(rand()%5)*0.1;
		 omega4=(rand()%5)*0.1;
		 omega5=(rand()%5)*0.1;
		 double B[8]={0,0,0,0,0,0,0,0};
      for(i=0;i<100;i++){
			Simu(1);
			for(j=0;j<8;j++){
      B[j]=B[j]+A[j];
			   }
	  	} 
		  fnew=0;
		  for(i=0;i<8;i++){
      Aver[i]=B[i]/1000000;
			fnew=fnew+(Aver[i]-R[i])*(Aver[i]-R[i])*10000; 
		  }
	  	fnew=fnew/8;
      
			double de=f-fnew;
      if(de >= 0){
				S[0]=theta1; S[1]=theta2; S[2]=deta1; S[3]=omega1;
				S[4]=omega2; S[5]=omega3; S[6]=omega4; S[7]=omega5;
				f=fnew;
			}
      else{
				if((double)rand()/RAND_MAX < exp(de/T)){
				S[0]=theta1; S[1]=theta2; S[2]=deta1; S[3]=omega1;
				S[4]=omega2; S[5]=omega3; S[6]=omega4; S[7]=omega5;
				f=fnew;
				}
			}
      T=r*T;
			k++;
			fout1<<S[0] << " " << S[1] << " " << S[2] <<" "  << S[3] << " " << S[4]<< " "<< S[5] << " " << S[6]<< " " << S[7] << " " << f <<endl;
			cout << k << endl; 
		} 
 

}

void impG(vector<int>point[],string filename){
    int a,b;
	ifstream fin(filename.c_str());

	if(!fin){//test if succeed in opening "filename"
      cout<<"fail to open the file!"<<endl;
	  exit(1);//close all processes,�쳣�˳���1��������ϵͳ;
	  return;
	}

	//Here we use a undirected graph
	for(int i=0;i<N;i++){
		point[i].clear();
	}
	while(fin>>a>>b){//after fin.open,we use">>"��ȡ����,�Կո�Ϊ�ָ�������ȡ��
      if(a < 0 || b < 0){ cout<< "ERROR node id"; return;}
      if(a < N && b < N) {
	                      point[a].push_back(b);
	                      point[b].push_back(a); }//��vectorβ������һ�����ݣ�
	}
}

void Dynamics(vector<int>point[],int state[],double theta1, double theta2, double deta1,double mu1,double mu2,double omega,Opinion w[]){
	//theta1����һ�� 
	int i,j,k,l,ran,temp;
	int p[N];
	int label[N];//�����нڵ�ӱ�ǩ��0δ����1������
	for(i = 0; i < N; i++){
     label[i] = 0;
     p[i]=i;
	}
	
	for(i=0;i<N;i++){
		ran=rand()%N;
		temp=p[ran];
		p[ran]=p[i];
		p[i]=temp;
	}
	
	for(i=0;i<N;i++){
		label[p[i]]=1;
		if((double) rand()/RAND_MAX < omega){
			if (fabs(w[p[i]].current-theta1)<deta1){
		 	state[p[i]]=1;
		 	w[p[i]].future=(1-mu1)*w[p[i]].current+mu1*theta1;
		 	w[p[i]].current= w[p[i]].future; 
		 	}
   	        else{//���ھ����û����� 
		     int h=point[p[i]].size();
             if(h>0){
		     k=rand()%h;
		      if(fabs(w[p[i]].current-w[point[p[i]][k]].current)<deta1){//���ھ����� 
		    	w[p[i]].future=(1-mu2)*w[p[i]].current+mu2*w[point[p[i]][k]].current;
		 	    w[p[i]].current= w[p[i]].future; 	
			  }
			  else{//���� 
				int a=point[p[i]][k];
		    	point[p[i]].erase(point[p[i]].begin()+k);//ɾ��p[i]�ĵ�k���ߣ�p[i],a���ߣ� 
		 	    point[a].erase(remove(point[a].begin(), point[a].end(), p[i]), point[a].end());//ɾ��a,p[i]���� 
                int b,d,e,f;
			    int c[N]={0};
				    c[p[i]]=1;
			     vector<int>g;
			    for(d=0;d<point[p[i]].size();d++){
				c[point[p[i]][d]]=1;
				}
		    	for(d=0;d<N;d++){
				if(c[d]==0 && fabs(w[p[i]].current-w[d].current)<deta1){
				g.push_back(d);
				  }
				}
			    if(g.size()>0){
				e=rand()%g.size();
				b=g[e];	 	  	    
				point[p[i]].push_back(b);
				point[b].push_back(p[i]);	
				}		
		      }
		    }
		  }
        }
        else{
			if (fabs(w[p[i]].current-theta2)<deta1){
		 	state[p[i]]=2;
		 	w[p[i]].future=(1-mu1)*w[p[i]].current+mu1*theta2;
		 	w[p[i]].current= w[p[i]].future; 
		 	}
   	        else{//���ھ����û����� 
		     int h=point[p[i]].size();
             if(h>0){
		     k=rand()%h;
		      if(fabs(w[p[i]].current-w[point[p[i]][k]].current)<deta1){//���ھ����� 
		    	w[p[i]].future=(1-mu2)*w[p[i]].current+mu2*w[point[p[i]][k]].current;
		 	    w[p[i]].current= w[p[i]].future; 	
			  }
			  else{//���� 
				int a=point[p[i]][k];
		    	point[p[i]].erase(point[p[i]].begin()+k);//ɾ��p[i]�ĵ�k���ߣ�p[i],a���ߣ� 
		 	    point[a].erase(remove(point[a].begin(), point[a].end(), p[i]), point[a].end());//ɾ��a,p[i]���� 
                int b,d,e,f;
			    int c[N]={0};
				    c[p[i]]=1;
			     vector<int>g;
			    for(d=0;d<point[p[i]].size();d++){
				c[point[p[i]][d]]=1;
				}
		    	for(d=0;d<N;d++){
				if(c[d]==0 && fabs(w[p[i]].current-w[d].current)<deta1){
				g.push_back(d);
				  }
				}
			    if(g.size()>0){
				e=rand()%g.size();
				b=g[e];	 	  	    
				point[p[i]].push_back(b);
				point[b].push_back(p[i]);	
				}		
		      }
		    }
		  }
		}
  
	}
		

        
}
    

Spr summary(int state[]){
	Spr spr={0};
	int i;
	for(i=0;i<N;i++){
		if(state[i]==0) spr.ign++;
		if(state[i]==1) spr.s1++;
		if(state[i]==2) spr.s2++;
	}
	return spr;
}

void Simu(int s){
string graph="ER.txt";  //��ȡͼtxt

int i,j,k,l,t;
Spr spr;
impG(point,graph);

 for(i=1; i <= s; i++){
    for(j=0;j<N;j++){//״̬��ֵ 
	  state[j]=0;
    }

    for(j=0;j<N;j++){//������ȷֲ� 
  	   w[j].current= (double) rand()/RAND_MAX;
  	   w[j].future=w[j].current;
    }
    
   
    Dynamics(point,state,theta1,theta2,deta1,mu1,mu2,omega1,w);
    spr=summary(state);
    
    
    Dynamics(point,state,theta1,theta2,deta1,mu1,mu2,omega2,w);
    spr=summary(state);
    A[0]=spr.s1; A[4]=spr.s2;
    
    Dynamics(point,state,theta1,theta2,deta1,mu1,mu2,omega3,w);
    spr=summary(state);
    A[1]=spr.s1; A[5]=spr.s2;
    
    Dynamics(point,state,theta1,theta2,deta1,mu1,mu2,omega4,w);
    spr=summary(state);
    A[2]=spr.s1; A[6]=spr.s2;
    
    Dynamics(point,state,theta1,theta2,deta1,mu1,mu2,omega5,w);
    spr=summary(state);
    A[3]=spr.s1; A[7]=spr.s2;

  }

} 

