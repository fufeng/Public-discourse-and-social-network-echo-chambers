#!python3
import networkx as nx
import csv
import community
import itertools
from numba import jit


def handle():
    G = nx.DiGraph()
    FileName = "./firstdebate.csv"
    weightMap = {}
    edgeWeight={}
    with open(FileName) as inputCsv:
        readCsv = csv.reader(inputCsv)
        for row in readCsv:
            if row[0] != 'Source':
                uv='%s,%s'%(row[0],row[1])
                if uv  not in edgeWeight:
                    edgeWeight[uv]=1
                else:
                    edgeWeight[uv]+=1
    print(edgeWeight.items())
    edges=[(uv.split(',')[0],uv.split(',')[1],w) for uv,w in edgeWeight.items()]
    G.add_weighted_edges_from(edges)
    print(len(G.nodes()))
    G = nx.DiGraph(max(nx.weakly_connected_component_subgraphs(G), key=len))
    Gc = G.copy()
    for nd in Gc.nodes():
        if Gc.in_degree(nd) == 0 and Gc.out_degree(nd) == 1:
            G.remove_node(nd)
        weightMap[nd] = Gc.in_degree(nd)
    print("points: ",len(G))
    print("edge: ",len(G.edges()))
        # print(weightMap)
        # for u,v in G.edges():
        #     print(u,v)
    while True:
        res=float(input("input resolution:"))
        partK = dict(community.best_partition(G.to_undirected(),resolution=res))
        # for i in part.items():
        #     print(i)
        part=sorted(partK.items(),key=lambda x:x[1])
        partS=[(k,len(list(g))/len(part)) for k,g in itertools.groupby(part,key=lambda x:x[1])]
        print(sorted(partS,key=lambda x:x[1],reverse=True))
        for k,v in sorted(partS,key=lambda x:x[1],reverse=True)[:3]:
            print(k,format(v,'.2%'))
        wsum=(sum(map(lambda x:weightMap[x],G.nodes())))
        wpmap={}
        for nd in G.nodes():
            if partK[nd] not in wpmap:
                wpmap[partK[nd]]=weightMap[nd]
            else:
                wpmap[partK[nd]]+=weightMap[nd]
        for k,v in sorted(wpmap.items(),key=lambda x:x[1],reverse=True)[:3]:
            print(k, format(v/wsum,'.2%'))
        confirm=int(input("confirm?:"))
        if confirm:
            break
    with open("output_edge.csv","w") as edgeCsv, open("output_point.csv","w") as pointCsv:
        writeEdge,writePoint=csv.writer(edgeCsv),csv.writer(pointCsv)
        writeEdge.writerow(["Source","Target","weight"])
        writePoint.writerow(["Id","weight","community"])
        for u,v,d in G.edges.data():
            writeEdge.writerow([u,v,d["weight"]])
        for nd in G.nodes():
            writePoint.writerow([nd,weightMap[nd],partK[nd]])
    #%%




handle()
